// ============================================
// Scroll-triggered reveal for case studies & skill cards
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  const revealTargets = document.querySelectorAll('.case, .skill-card');

  revealTargets.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(24px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  });

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  revealTargets.forEach(el => observer.observe(el));

  // Respect reduced-motion preference: skip the animated reveal entirely
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    revealTargets.forEach(el => {
      el.style.opacity = '1';
      el.style.transform = 'none';
      el.style.transition = 'none';
    });
  }
});

// ============================================
// Nav status dot — swap text if you go unavailable
// Edit the string below to update your availability message
// ============================================
const navStatus = document.querySelector('.nav__status');
if (navStatus) {
  navStatus.lastChild.textContent = 'AVAILABLE FOR HIRE';
}
